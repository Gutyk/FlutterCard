import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Color.fromARGB(255, 4, 58, 53),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 85,
                backgroundImage: AssetImage('images/card.png'),
              ),
              Text(
                'Killua', 
              style: TextStyle(
                fontSize: 40,
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontFamily: 'Pacifico',
              ), 
              ),
              SizedBox(width: 250, 
              child: Divider(
                height: 20, 
                color: Colors.teal[100],
              ),
              ),
              Text('Hunter',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
                color: Colors.teal[100],
              ),),
              Card(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Row(
                    children: [
                    Icon(Icons.phone),
                    SizedBox(
                      width: 20,
                    ),
                    Text('+55 1100000000',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.teal,
                    ),
                    )
                  ],),
                ),
              ),
              Card(
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Row(
                    children: [
                    Icon(Icons.mail),
                    SizedBox(
                      width: 20,
                    ),
                    Text('hunterkillua@hunters.com',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.teal,
                    ),
                    )
                  ],),
                ),
              ),
          ]),
        ),
      ),
    );
    
  }
}
